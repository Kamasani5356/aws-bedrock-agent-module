# 🤖 Terraform Module: AWS Bedrock Agent

Deploys a production-ready **Amazon Bedrock Agent** with:
- IAM execution role (trust + permissions, scoped to Bedrock service)
- Lambda function as the action group handler (with IAM + resource-based policy)
- Bedrock Agent + Action Group + Alias (all referencing Terraform Registry resources)
- CloudWatch log group for observability
- Optional: Memory, Guardrail, KMS encryption

---

## 📁 File Structure

```
terraform-bedrock-agent/
├── main.tf                   # All AWS resources
├── variables.tf              # All input variables with descriptions + validations
├── outputs.tf                # All exported values + invoke helpers
├── example.tf                # 3 usage examples (minimal, full, model-only)
└── terraform.tfvars.example  # Template for variable values
```

---

## 🚀 Quick Start

```bash
cp terraform.tfvars.example terraform.tfvars

terraform init
terraform plan
terraform apply
```

After apply, copy the `invoke_command` output to test your agent:

```bash
aws bedrock-agent-runtime invoke-agent \
  --agent-id <AGENT_ID> \
  --agent-alias-id <ALIAS_ID> \
  --session-id test-session-1 \
  --input-text "What is today's date?"
```

---

## ⚙️ Key Resources (Registry links)

| Resource | Terraform Registry |
|---|---|
| `aws_bedrockagent_agent` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_agent) |
| `aws_bedrockagent_agent_alias` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_agent_alias) |
| `aws_bedrockagent_agent_action_group` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_agent_action_group) |
| `aws_iam_role` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) |
| `aws_lambda_function` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) |
| `aws_cloudwatch_log_group` | [hashicorp/aws](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) |

---

## 📋 Prerequisites

1. AWS account with Bedrock available in your region
2. Model access enabled (Bedrock console → Model access → Enable Claude)
3. Terraform >= 1.5.0 and AWS provider >= 5.40.0
4. IAM permissions: `bedrock:*`, `iam:*`, `lambda:*`, `logs:*`

---

## 🔑 Required Variables

| Variable | Description |
|---|---|
| `name_prefix` | Prefix for all resource names (e.g. `myapp-prod`) |
| `agent_instruction` | System prompt for the agent (min 40 chars) |

All other variables have defaults.

---

## 💡 Notes

- **`prepare_agent = true`** — Required so the agent can serve requests immediately after `apply`.
- **Lambda code** — The bundled Lambda is a placeholder. Edit `main.tf` > `data.archive_file` to deploy your own logic.
- **Model IDs** — Use the short model ID, not the ARN: `anthropic.claude-3-haiku-20240307-v1:0`
- **Regions** — Bedrock is available in: `us-east-1`, `us-west-2`, `eu-west-1`, `eu-central-1`, `ap-southeast-1`, `ap-northeast-1`
